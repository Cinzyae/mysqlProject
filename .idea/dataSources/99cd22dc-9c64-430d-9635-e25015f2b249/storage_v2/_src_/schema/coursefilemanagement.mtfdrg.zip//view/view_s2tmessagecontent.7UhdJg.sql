create definer = root@localhost view view_s2tmessagecontent as
select `coursefilemanagement`.`message`.`content` AS `content`
from `coursefilemanagement`.`message`
where (`coursefilemanagement`.`message`.`direction` = 0);

